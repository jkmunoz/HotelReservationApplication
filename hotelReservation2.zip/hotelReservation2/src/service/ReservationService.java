package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.*;

public class ReservationService {

    private static ReservationService INSTANCE = null;

    private ReservationService() {
    }

    public static ReservationService getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ReservationService();
        }
        return INSTANCE;
    }
    ArrayList<Reservation> reservations = new ArrayList<>();
    Map<String, IRoom> rooms = new HashMap<>();


    public void addRoom(IRoom room) {
        rooms.put(room.getRoomNumber(),room);
    }


    public IRoom getARoom(String roomID) {
        return rooms.get(roomID);
    }

    public Collection<IRoom> getAllRooms() {
        return rooms.values();
    }


    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        reservations.add(reservation);
        return reservation;
    }


    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {
        HashMap<String, IRoom> availableRooms = new HashMap<>(rooms);
        return new ArrayList<>(availableRooms.values());

    }


    public Collection<Reservation> getCustomersReservation(Customer customer) {
         ArrayList<Reservation> customerReservations = new ArrayList<>();

        for (Reservation reservation : reservations) {
            if (reservation.getCustomer().equals(customer)) {
                customerReservations.add(reservation);
            }
        }
        return customerReservations;
    }


    public void printAllReservation() {
        if (reservations.isEmpty()) {
            System.out.println("No reservations have been made.");
        } else {
            for (Reservation reservation : reservations) {
                System.out.println(reservation);
            }
        }
    }
}


