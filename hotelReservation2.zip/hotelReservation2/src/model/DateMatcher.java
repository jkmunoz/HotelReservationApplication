package model;


//https://www.baeldung.com/java-date-regular-expressions
public interface DateMatcher {
    boolean matches(String date);
}
