/*

package model;

public class Tester {
    public static void main(String[] args) {
        Customer customer = new Customer
                ("Julianna", "Munoz", "blah");
        System.out.println(customer);
    }
}

 */
